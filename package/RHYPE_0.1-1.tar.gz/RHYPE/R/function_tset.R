
#' @export

#' @title
#' test whats not working here
#'
#' @description
#' blahahahahah
#' 
#'
#' 
#' 
#' @details
#' just resturns a string
#' 
#' @return
#' a string
#' 
#' 
#' @examples
#' tset()

tset <- function() {
  print("blubb")
}