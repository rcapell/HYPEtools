#' @title RHYPE
#'
#' @name RHYPE
#' @docType package
#' @description
#' This package contains functions to handle and analyse input and
#' output files from the conceptual rainfall-runoff model HYPE (HYdrological
#' Predictions for the Environment).

NULL
