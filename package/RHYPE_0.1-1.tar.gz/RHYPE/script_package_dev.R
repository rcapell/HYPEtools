remove.packages("RHYPE")
setwd("d:/Rpackage_dev/r302/RHYPE")
library("devtools")
library("RHYPE")
load_all()
document()
dev_help("RHYPE")
dev_help("tset")
dev_help("ExtractFreq")
dev_help("FindUpstreamSubids")
install()
tset()
ExtractFreq(rnorm(1000))
devtools::build(binary = T)

install_github("rcapell/RHYPE@master", password = "")

xobsloc <- "//winfs/data/arkiv/proj/FoUhArkiv/Sweden/S-HYPE/S-HYPE2012B/Leverans,2013-09-30/Xobs.txt"
gdloc <- "//winfs/data/arkiv/proj/FoUhArkiv/Sweden/S-HYPE/S-HYPE2012B/Leverans,2013-09-30/GeoData.txt"
bdloc <- "//winfs/data/arkiv/proj/FoUhArkiv/Sweden/S-HYPE/S-HYPE2012B/Leverans,2013-09-30/BranchData.txt"
cdloc <- "//winfs/data/arkiv/proj/FoUhArkiv/Sweden/S-HYPE/S-HYPE2012B/Leverans,2013-09-30/CropData.txt"
parloc <- "//winfs/data/arkiv/proj/FoUhArkiv/Sweden/S-HYPE/S-HYPE2012B/Leverans,2013-09-30/par.txt"
pobsloc <- "//winfs/data/prod/Hydrologisk_Produktion/HYPE/Drivdatafiler/S-HYPE/S-HYPE_2012/PobsTobsS-hype2012_version_1_2_0_1960-2013-07-31_2012_slutgranskad/Pobs_sh2012_v_1_1_2_1960_2013.txt"
xobs <- read.table(xobsloc, skip=3, nrows=2)
pobs <- read.table(pobsloc, skip=0,, header=T, nrows=2)

